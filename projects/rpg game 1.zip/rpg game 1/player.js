class Player {
    constructor(name){
        this.name = name;
    }
}

export { Player };